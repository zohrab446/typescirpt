function sayHello() {
    // let can = "Can";
    console.log('Hi');
    // return can;
}
sayHello();
