var sayac = 0;
// let sayac:number = 0;
console.log(typeof (sayac));
// function increment(counter: number){
//     return counter++;
// }
function increment(counter) {
    return counter++;
}
// let a ="some text";
// let b = 123;
// a=b;
function sum(a, b) {
    return a + b;
}
// let total:number = sum(10,15);
var total = sum(10, 15);
