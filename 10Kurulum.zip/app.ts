let someThing: any = "Hello";
someThing = 45;
someThing = true;
someThing = {
    firstName: 'Can',
    lastName: 'Boz',
}
console.log(someThing);

let arr: any[] = ["John", 212, true];
console.log(arr);