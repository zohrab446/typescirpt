function throwError(errorMsg) {
    throw new Error(errorMsg);
}
throwError("Hata");
var something = null;
var nothing = null;
