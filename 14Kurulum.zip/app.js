// let code: any = 123;
var employee = {};
console.log(typeof (employee));
employee.name = "Can";
console.log(employee);
